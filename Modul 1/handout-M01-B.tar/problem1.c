#include <stdio.h>

int main(){

	return 0;
}