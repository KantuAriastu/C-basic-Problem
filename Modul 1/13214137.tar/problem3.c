// Praktikum EL2208 Pemecahan Masalah dengan C
// Modul : 1
// Percobaan : 3
// Tanggal : 16 February 2016
// Nama (NIM) : Ngakan Putu Ariastu Krisnadi Rata (13214137)
// Nama File : problem3.c
// Deskripsi : meminta bilangan integer pada user dan menampilkan pada layar

#include <stdio.h>

int main(){ /*prosedur utama*/
    int x; /*deklrasi variable*/

    printf("Masukkan bilangan integer x :\n");
    scanf("%d",&x); /*meminta dan membaca nilai masukan*/
    printf("Nilai variable x = %d\n",x); /*menulis output ke layar*/
	return 0;
}
