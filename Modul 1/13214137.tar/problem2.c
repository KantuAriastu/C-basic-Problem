// Praktikum EL2208 Pemecahan Masalah dengan C
// Modul : 1
// Percobaan : 2
// Tanggal : 16 February 2016
// Nama (NIM) : Ngakan Putu Ariastu Krisnadi Rata (13214137)
// Nama File : problem2.c
// Deskripsi : Menampilkan nilai suatu type data integer x yakni 5

#include <stdio.h>

int main(){
    int x =5; /*deklarasi variable dengan nilai 5*/
    printf("Nilai variable x = %d\n",x); /*menuliskan output ke layar*/
	return 0;
}
