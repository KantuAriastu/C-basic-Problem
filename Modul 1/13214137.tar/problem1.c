// Praktikum EL2208 Pemecahan Masalah dengan C
// Modul : 1
// Percobaan : 1
// Tanggal : 16 February 2016
// Nama (NIM) : Ngakan Putu Ariastu Krisnadi Rata (13214137)
// Nama File : problem1.c
// Deskripsi : Menampilkan tulisan Saya senang belajar bahasa C, enter. Saya
//              praktikum pada hari selasa

#include <stdio.h>

int main(){ /*prosedur utama*/
    printf("Saya senang belajar bahasa C!\n"); /*menuliskan output kalimat ke layar dengan enter*/
    printf("Saya praktikum PMC pada hari selasa.\n"); /*menuliskan output kalimat ke layar */
	return 0;
}
