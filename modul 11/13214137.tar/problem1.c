/* Praktikum EL2208 Pemecahan Masalah dengan C
 * Modul          : 11
 * Percobaan      : 0 (TP)
 * Tanggal        : 5 April 2016
 * Nama (NIM)     : Ngakan Putu Ariastu (13214137)
 * Nama File      : problem1.c
 *
 * Deskripsi      : program dengan structure data stuck 5 buah yg sudah diinisialisasi
 *                  user diminta membuat pilihan untuk mengeluarkan nilai stack hingga
                    stack kosong.
*/
#include <stdio.h>

typedef struct stacktype {//structure data stacktype
    double A[5];
    int Top;
}stacktype;

void pop ();
int main(void)
{   //deklarasi variable
	stacktype stack1;
	char in;
	//inisialisasi stack
	stack1.Top=4;
	stack1.A[4]=0.01;
	stack1.A[3]=-12;
	stack1.A[2]=9;
	stack1.A[1]=10;
	stack1.A[0]=3.5;

    while (stack1.Top>=0){ //output
        printf ("Data teratas stack saat ini : %.2lf\n",stack1.A[stack1.Top]);
        printf ("Apakah Anda akan mengeluarkannya (Y/N) ?\n");
        scanf ("%c%*c",&in);
        if (in == 'y'){
            printf ("Data yang dikeluarkan : %.2lf\n",stack1.A[stack1.Top]);
            pop(&stack1.Top); //pop
        }
    }
        printf("Stack sudah kosong. Terima kasih sudah mengosongkan stack ini.\n");
	return 0;
}
void pop(int *Top){//prosedur pop stack
    *Top= *Top-1;
}
