#include <stdio.h>
int main(){

    printf("Masukkan panjang kaki segitiga :\n");

	printf("*");
	
	printf("\n");

	return 0;
}
