#include <stdio.h>
#include <math.h>
int main(){

    printf("Masukkan nilai x0 :\n");

	printf("n\tx\n");

	printf("%\t%\n");

    printf("%\t%\n";

	return 0;
}
