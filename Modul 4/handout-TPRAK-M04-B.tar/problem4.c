#include <stdio.h>
#include <math.h>
#define pi 3.14159265
int main(){
	
    printf("Masukkan besar sudut dalam derajat :\n");

    printf("Hasil eksak : %\nHasil pendekatan taylor : %\nError : % %%\n");
	return 0;
}
