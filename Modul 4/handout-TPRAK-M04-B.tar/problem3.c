#include <stdio.h>
int main(){

	printf("Masukkan nilai integer :\n");

	printf("Input harus berada pada rentang 100-200!\nMasukkan nilai integer :\n");

    printf("Rata-rata dari % bilangan tersebut adalah %\n");
	return 0;
}
