// Praktikum EL2208 Pemecahan Masalah dengan C
// Modul : 4
// Percobaan : 4
// Tanggal : 26 February 2016
// Nama (NIM) : Ngakan Putu Ariastu Krisnadi Rata (13214137)
// Nama File : problem4.c
// Deskripsi : menghitung nilai cos dengan deret dan membandingkan dengan hasil eksak

#include <stdio.h>
#include <math.h>
#define pi 3.14159265
int main(){
    float hasil,hasilmath,sudut,sudutrad; //deklrasi variable
    int count,i,j;
    float x,fak;
    float error,selisih;

    printf("Masukkan besar sudut dalam derajat :\n"); //meminta input
    scanf("%f",&sudut);
    sudutrad=sudut*pi/180;
    count=0;
    hasil=1;
    for (i=1;i<=4;i++){   //proses deret
        x=1;
        fak=1;
        if (i%2==0) {
                count=count+1;
                for (j=1;j<=i;j++){
                    x=x*sudutrad;
                }
                for (j=1;j<=i;j++){
                    fak=fak*j;
                }
                if (count%2==0){
                    hasil=hasil+(x/fak);
                }
                else if (count%2!=0){
                    hasil=hasil-(x/fak);
                }
        }
    }
    hasilmath = cos(sudutrad); //proses nilai eksak
    selisih=hasil-hasilmath;
    error=fabs(selisih)/hasilmath*100; //proses eror

    printf("Hasil eksak : %.10f\n",hasilmath); //menampilkan ke layar
    printf("Hasil pendekatan taylor : %.10f\n",hasil);
    printf("Error : %.10f %%\n",error);
	return 0;
}
