//LIBRARY problem1lib.h
//BERISI DEKLARASI FUNGSI
//INTEGRAL RIEMAN DAN BEBERAPA FUNGSI FX YANG MUNGKIN

double f1 (double x);

double f2 (double x);

double f3 (double x);

double rRect (int a, int b, int n, int f);

double lRect (int a, int b, int n, int f);

double mRect (int a, int b, int n, int f);

double tRule (int a, int b, int n, int f);

double sRule (int a, int b, int n, int f);

