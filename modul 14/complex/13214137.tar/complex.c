//  HEADERLIBRARY complex.h
// MENGIMPLEMENTASIKAN FUNGSI PADA LIBRARY
// DIIMPLEMENTASI SESUAI RUMUS BILANGAN KOMPLEKS

#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include "complex.h"
#define pi 3.14159265


complex getcomplex (char *masukan)
{
    complex a;
    sscanf(masukan,"%lf%lf",&a.real,&a.imag);
    return a;
}

double mag (complex a)
{
    double ans;
    ans = sqrt((a.real*a.real)+(a.imag*a.imag));
    return ans;
}

double phase (complex a)
{   double ans;
    ans = atan(a.imag/a.real);
    ans = ans *180/pi;
    return ans;
}

complex add (complex a, complex b)
{
    complex ans;
    ans.real = a.real + b.real;
    ans.imag = a.imag + b.imag;
    return ans;
}

complex substract (complex a, complex b)
{
    complex ans;
    ans.real = a.real - b.real;
    ans.imag = a.imag - b.imag;
    return ans;
}

complex multiply (complex a, complex b)
{
    complex ans;
    ans.real = a.real*b.real - a.imag*b.imag;
    ans.imag = a.imag*b.real + a.real*b.imag;
    return ans;
}

complex divide (complex num, complex denum)
{
    complex ans;
    ans.real = (num.real*denum.real + num.imag*denum.imag)/(denum.real*denum.real + denum.imag*denum.imag);
    ans.imag = (num.imag*denum.real - num.real*denum.imag)/(denum.real*denum.real + denum.imag*denum.imag);
    return ans;
}




