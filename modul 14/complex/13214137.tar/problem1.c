/* Praktikum EL2208 Pemecahan Masalah dengan C
 * Modul          : 14
 * Percobaan      : 0 TP
 * Tanggal        : 15 April 2016
 * Nama (NIM)     : Ngakan Putu Ariastu Krisnadi Rata (13214137)
 * Nama File      : problem1.c
 *
 * Deskripsi      : memilih operasi pada bilangan kompleks dan meminta input tergantung opearasi yang dipilih
 *                  lalu mengeluarkan outputnya. Implementasi fungsi dengan menggunakan library
 */

#include <stdio.h>
#include <string.h>
#include "complex.h" //memanggil librray yang telah dibuat

//PROGRAM UTAMA
int main(int argc, char *argv[])
{
	//DEKLARASI VARIABLE pada setiap percabangan


    //ALGORITMA
    if (strcmp(argv[1],"mag")==0)       //percabangan opt
    {
        complex a = getcomplex(argv[2]); //mengambil nilai complex dari pembacaan terminal
        double ans = mag(a);           //deklarasi penyimpan nilai ans bervariasi bergantung percabangan
        printf("Magnitude Bilangan Kompleks\n");
        printf("c = %s\nMagnitude (c) = %.2lf \n",argv[2],ans); //output
    }
    else if (strcmp(argv[1],"ph")==0)
    {
        complex a = getcomplex(argv[2]);
        double ans = phase(a);
        printf("Phase Bilangan Kompleks\n");
        printf("c = %s\nPhase (c) = %.2lf \n",argv[2],ans); //output
    }
    else if (strcmp(argv[1],"add")==0)
    {
        complex a = getcomplex(argv[2]);
        complex b = getcomplex(argv[3]);
        complex ans = add(a,b);
        printf("Penjumlahan Bilangan Kompleks\n");
        printf("c1 = %s\nc2 = %s\nc1 + c2 = %.2lf + (%.2lfi)\n",argv[2],argv[3],ans.real,ans.imag); //ouput
    }
    else if (strcmp(argv[1],"sub")==0)
    {
        complex a = getcomplex(argv[2]);
        complex b = getcomplex(argv[3]);
        complex ans = substract(a,b);
        printf("Pengurangan Bilangan Kompleks\n");
        printf("c1 = %s\nc2 = %s\nc1 - c2 = %.2lf + (%.2lfi)\n",argv[2],argv[3],ans.real,ans.imag); //output
    }
    else if (strcmp(argv[1],"mul")==0)
    {
        complex a = getcomplex(argv[2]);
        complex b = getcomplex(argv[3]);
        complex ans = multiply(a,b);
        printf("Perkalian Bilangan Kompleks\n");
        printf("c1 = %s\nc2 = %s\nc1 * c2 = %.2lf + (%.2lfi)\n",argv[2],argv[3],ans.real,ans.imag);//output
    }
    else if (strcmp(argv[1],"div")==0)
    {
        complex a = getcomplex(argv[2]);
        complex b = getcomplex(argv[3]);
        complex ans = divide(a,b);
        printf("Pembagian Bilangan Kompleks\n");
        printf("c1 = %s\nc2 = %s\nc1 / c2 = %.2lf + (%.2lfi)\n",argv[2],argv[3],ans.real,ans.imag); //output
    }
    else
    {
         printf("Input salah");//outpt apabila input tidak ada yang sesuai
    }
    return 0;
}
