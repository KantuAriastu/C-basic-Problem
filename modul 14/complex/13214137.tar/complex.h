// LIBRARY complex.h
// DEKLARASI FUNGSI

typedef struct
{
    double real;
    double imag;
}complex;

complex getcomplex (char *masukan);

double mag (complex a);

double phase (complex a);

complex add (complex a, complex b);

complex substract (complex a, complex b);

complex multiply (complex a, complex b);

complex divide (complex num, complex denum);

