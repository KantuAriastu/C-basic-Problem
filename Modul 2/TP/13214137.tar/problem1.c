// Praktikum EL2208 Pemecahan Masalah dengan C
// Modul : 2
// Percobaan : 0 (TP)
// Tanggal : 17 February 2016
// Nama (NIM) : Ngakan Putu Ariastu Krisnadi Rata (13214137)
// Nama File : problem1.c
// Deskripsi : Meminta dan input nilai jari2 lingkaran dan menampilkan luasnya

#include <stdio.h>

int main (){                                        /*prosedur utama */
    float pi = 3.1415926;                           /*deklrasai nilai dan variable*/
    float r;
    float Luas;

    printf("Masukkan jari-jari lingkaran (cm) :\n"); /*meminta masukan */
    scanf("%f",&r);
    Luas = pi*r*r;                                      /*proses luas*/
    printf("Luas lingkaran adalah %.2f cm2\n",Luas);  /*menampilkan ke layar*/

    return 0;

}
