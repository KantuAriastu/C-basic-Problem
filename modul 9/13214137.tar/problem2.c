/* Praktikum EL2208 Pemecahan Masalah dengan C
 * Modul          : 9
 * Percobaan      : 0 (TP 2)
 * Tanggal        : 28 Maret 2016
 * Nama (NIM)     : Ngakan Putu Ariastu (13214137)
 * Nama File      : problem2.c
 *
 * Deskripsi      : Program yang meminta jumlah elemen yang akan diinput kemudian menerima
 *                  data sebanyak yang diminta dan menampilkan urutan secara ascending
 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{   int *arr;
    int n,x,c,d,i,temp;

	printf("Masukkan jumlah elemen pada array :\n");
	scanf ("%d",&x);
	n=x-1;
	arr = (int*)malloc(x*sizeof(int));
    for (i=0;i<=n;i++){
        printf("Masukkan elemen ke-%d :\n",i);
        scanf("%d",&arr[i]);
    }

 for (c = 1 ; c <= n; c++) {   //pengururan insertion
    d = c;
    while ( d > 0 && arr[d] < arr[d-1]) {
      temp         = arr[d];
      arr[d]   = arr[d-1];
      arr[d-1] = temp;

      d--;
    }
  }

	printf("Array yang tersusun secara ascending :\n");
	for (i=0;i<=n-1;i++){
        printf("%d ",arr[i]);
    }
    printf("%d\n",arr[i]);
    free(arr);

  return 0;
}
