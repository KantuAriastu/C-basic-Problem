#include <stdio.h>
#include <math.h>
#define pi 3.141592654

// Deklarasi fungsi


int main(void){

	return 0;
}

//Definisi Fungsi

{

    printf("Masukkan sisi x :\n");

	printf("Masukkan sisi y :\n");

	printf("Masukkan sisi z :\n");

}

{

	printf("Nilai sudut a : %.3f derajat\n");
	printf("Nilai sudut b : %.3f derajat\n");
	printf("Nilai sudut c : %.3f derajat\n");
	printf("Luas segitiga : %.3f cm2\n");
}