#include <stdio.h>

int bil[1000001];

// Deklarasi prosedur

int main(void){
	printf("Masukkan banyaknya bilangan (n) :\n");

	printf("Masukkan bilangan ke - % :\n");

	printf("Hasil pengurutan bilangan :\n");

	printf("%\n");
	
	return 0;
}

// Definisi prosedur 