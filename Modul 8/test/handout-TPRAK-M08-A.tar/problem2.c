#include <stdio.h>

// Deklarasi Fungsi

int main(){

	printf("Kalkulator Berat Badan Ideal BMI\n");
	printf("Masukkan tinggi badan anda ( Meter ):\n");

	printf("Masukkan berat badan anda ( Kilogram ):\n");





        printf("BMI = %.2f, Under Weight\n",z);


        printf("BMI = %.2f, Normal Weight\n",z);

        printf("BMI = %.2f, Over Weight\n",z);

        printf("BMI = %.2f, Obese\n",z);

	return 0;
}

// Deklarasi

