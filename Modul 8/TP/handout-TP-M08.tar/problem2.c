#include <stdio.h>


// Deklarasi Prosedur disini
void bangunan(int x);

int main(){

	printf("Masukkan ketinggian bangunan :\n");

	return 0;

}


// Definisi Prosedur disini
{
    printf("    ****    \n");


	printf("************\n");
}
