#include <stdio.h>

// Deklarasi Fungsi disini

int main(){

printf("Masukkan sudut dalam derajat :\n");

printf("Hasil konversi sudut ke radian adalah : % rad\n");

return 0;

}

// Definisi fungsi disini

