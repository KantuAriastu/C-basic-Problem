// Praktikum EL2208 Pemecahan Masalah dengan C
// Modul : 5
// Percobaan : 0 TP
// Tanggal : 1 Maret 2016
// Nama (NIM) : Ngakan Putu Ariastu Krisnadi Rata (13214137)
// Nama File : problem1.c
// Deskripsi : menginput suatu deret bilangan pada array dan menuliskan banyak bilangan yang di minta

#include <stdio.h>1

int main(){
   int arrayin [10];  //deklrasi variable
   int i,in,count;

    //algoritma
    printf("Masukkan 10 bilangan integer :\n"); //input array
    for (i=0;i<=9;i++){
        scanf("%d",&arrayin[i]);
   }
    printf("Masukkan bilangan integer yang dicari :\n"); //minput nilai integer yg dicari
    scanf("%d",&in);
    count=0;
    for (i=0;i<=9;i++){   //looping penghitungan angka
        if (arrayin[i]==in){
            count=count+1;
        }
   }
   if (count>0){  //percabangan memunculkan hasil pencarian
        printf("%d muncul sebanyak %d kali\n",in,count);
   }
   else {
        printf("%d Tidak ditemukan\n",in);
   }
	return 0;
}
